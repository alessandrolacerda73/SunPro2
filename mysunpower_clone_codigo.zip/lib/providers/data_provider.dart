import 'package:flutter/material.dart';
import '../services/solar_data_service.dart';

class DataProvider extends ChangeNotifier {
  final SolarDataService _dataService = SolarDataService();
  
  // Estado de conexão
  bool _isConnected = false;
  bool get isConnected => _isConnected;
  
  // Dados atuais
  Map<String, dynamic>? _currentGenerationData;
  Map<String, dynamic>? _batteryData;
  Map<String, dynamic>? _weatherData;
  Map<String, dynamic>? _historicalData;
  
  // Getters para dados
  Map<String, dynamic>? get currentGenerationData => _currentGenerationData;
  Map<String, dynamic>? get batteryData => _batteryData;
  Map<String, dynamic>? get weatherData => _weatherData;
  Map<String, dynamic>? get historicalData => _historicalData;
  
  // Configurar conexão
  Future<bool> configureConnection({
    required String manufacturer,
    String? customApiUrl,
    String? apiKey,
    String? systemId,
  }) async {
    try {
      SolarDataService.ManufacturerType type;
      
      switch (manufacturer) {
        case 'sunpower':
          type = SolarDataService.ManufacturerType.sunpower;
          break;
        case 'fronius':
          type = SolarDataService.ManufacturerType.fronius;
          break;
        case 'solaredge':
          type = SolarDataService.ManufacturerType.solaredge;
          break;
        case 'enphase':
          type = SolarDataService.ManufacturerType.enphase;
          break;
        case 'huawei':
          type = SolarDataService.ManufacturerType.huawei;
          break;
        case 'custom':
        default:
          type = SolarDataService.ManufacturerType.custom;
          break;
      }
      
      final success = await _dataService.configureConnection(
        manufacturer: type,
        customApiUrl: customApiUrl,
        apiKey: apiKey,
        systemId: systemId,
      );
      
      _isConnected = success;
      notifyListeners();
      
      if (success) {
        // Carregar dados iniciais
        await refreshAllData();
      }
      
      return success;
    } catch (e) {
      _isConnected = false;
      notifyListeners();
      return false;
    }
  }
  
  // Atualizar todos os dados
  Future<void> refreshAllData() async {
    if (!_isConnected) return;
    
    try {
      await Future.wait([
        refreshCurrentGeneration(),
        refreshBatteryData(),
        refreshWeatherData(),
        refreshHistoricalData('day'),
      ]);
    } catch (e) {
      print('Erro ao atualizar dados: $e');
    }
  }
  
  // Atualizar dados de geração atual
  Future<void> refreshCurrentGeneration() async {
    if (!_isConnected) return;
    
    try {
      _currentGenerationData = await _dataService.getCurrentGeneration();
      notifyListeners();
    } catch (e) {
      print('Erro ao atualizar dados de geração: $e');
    }
  }
  
  // Atualizar dados da bateria
  Future<void> refreshBatteryData() async {
    if (!_isConnected) return;
    
    try {
      _batteryData = await _dataService.getBatteryData();
      notifyListeners();
    } catch (e) {
      print('Erro ao atualizar dados da bateria: $e');
    }
  }
  
  // Atualizar dados meteorológicos
  Future<void> refreshWeatherData() async {
    if (!_isConnected) return;
    
    try {
      _weatherData = await _dataService.getWeatherData();
      notifyListeners();
    } catch (e) {
      print('Erro ao atualizar dados meteorológicos: $e');
    }
  }
  
  // Atualizar dados históricos
  Future<void> refreshHistoricalData(String period) async {
    if (!_isConnected) return;
    
    try {
      _historicalData = await _dataService.getHistoricalData(period);
      notifyListeners();
    } catch (e) {
      print('Erro ao atualizar dados históricos: $e');
    }
  }
  
  // Desconectar
  void disconnect() {
    _isConnected = false;
    _currentGenerationData = null;
    _batteryData = null;
    _weatherData = null;
    _historicalData = null;
    notifyListeners();
  }
}
