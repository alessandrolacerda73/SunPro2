import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:http/http.dart' as http;

/// Classe que gerencia a conexão com dados externos de sistemas solares
class SolarDataService {
  // Singleton pattern
  static final SolarDataService _instance = SolarDataService._internal();
  factory SolarDataService() => _instance;
  SolarDataService._internal();

  // Tipos de fabricantes suportados
  enum ManufacturerType {
    sunpower,
    fronius,
    solaredge,
    enphase,
    huawei,
    custom
  }

  // Fabricante atual
  ManufacturerType _currentManufacturer = ManufacturerType.custom;
  String _customApiUrl = '';
  String _apiKey = '';
  String _systemId = '';

  // Getters
  ManufacturerType get currentManufacturer => _currentManufacturer;
  String get customApiUrl => _customApiUrl;
  String get apiKey => _apiKey;
  String get systemId => _systemId;

  // Configurar conexão com fabricante específico
  Future<bool> configureConnection({
    required ManufacturerType manufacturer,
    String? customApiUrl,
    String? apiKey,
    String? systemId,
  }) async {
    _currentManufacturer = manufacturer;
    
    if (apiKey != null) {
      _apiKey = apiKey;
    }
    
    if (systemId != null) {
      _systemId = systemId;
    }
    
    if (manufacturer == ManufacturerType.custom && customApiUrl != null) {
      _customApiUrl = customApiUrl;
    }
    
    // Testar conexão
    try {
      await testConnection();
      return true;
    } catch (e) {
      print('Erro ao configurar conexão: $e');
      return false;
    }
  }

  // Testar conexão com a API
  Future<bool> testConnection() async {
    // Em um aplicativo real, isso faria uma chamada de teste para a API
    // Para fins de demonstração, retornamos sucesso
    return Future.delayed(const Duration(seconds: 1), () => true);
  }

  // Obter dados de geração atual
  Future<Map<String, dynamic>> getCurrentGeneration() async {
    // Em um aplicativo real, isso faria uma chamada para a API do fabricante
    // Para fins de demonstração, geramos dados simulados
    return Future.delayed(
      const Duration(seconds: 1),
      () {
        final now = DateTime.now();
        final hour = now.hour;
        
        // Simular curva de geração solar ao longo do dia
        double generationFactor = 0;
        if (hour >= 6 && hour <= 18) {
          // Curva em forma de sino centrada ao meio-dia
          generationFactor = 1 - (math.pow(hour - 12, 2) / 36);
        }
        
        // Adicionar variação aleatória
        final random = math.Random();
        final randomFactor = 0.8 + random.nextDouble() * 0.4; // 0.8 a 1.2
        
        // Calcular valores
        final currentPower = (5.0 * generationFactor * randomFactor).toStringAsFixed(1);
        final dailyEnergy = (24.0 * generationFactor * randomFactor).toStringAsFixed(1);
        final batteryLevel = (60 + random.nextInt(30)).toString();
        
        return {
          'currentPower': '$currentPower kW',
          'dailyEnergy': '$dailyEnergy kWh',
          'batteryLevel': '$batteryLevel%',
          'timestamp': now.toIso8601String(),
        };
      },
    );
  }

  // Obter dados históricos de geração
  Future<Map<String, dynamic>> getHistoricalData(String period) async {
    // Em um aplicativo real, isso faria uma chamada para a API do fabricante
    // Para fins de demonstração, geramos dados simulados
    return Future.delayed(
      const Duration(seconds: 1),
      () {
        final random = math.Random();
        List<Map<String, dynamic>> data = [];
        
        if (period == 'day') {
          // Dados para um dia (horários)
          for (int hour = 6; hour <= 18; hour++) {
            // Curva em forma de sino centrada ao meio-dia
            final generationFactor = 1 - (math.pow(hour - 12, 2) / 36);
            final randomFactor = 0.8 + random.nextDouble() * 0.4; // 0.8 a 1.2
            final value = (5.0 * generationFactor * randomFactor);
            
            data.add({
              'time': '$hour:00',
              'value': value.toStringAsFixed(1),
            });
          }
        } else if (period == 'week') {
          // Dados para uma semana (dias)
          final days = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
          for (int i = 0; i < 7; i++) {
            // Variação aleatória com tendência para mais sol nos fins de semana
            final weekendBonus = (i >= 5) ? 0.2 : 0.0;
            final randomFactor = 0.7 + random.nextDouble() * 0.6 + weekendBonus;
            final value = 20.0 * randomFactor;
            
            data.add({
              'time': days[i],
              'value': value.toStringAsFixed(1),
            });
          }
        } else if (period == 'month') {
          // Dados para um mês (semanas)
          for (int week = 1; week <= 4; week++) {
            final randomFactor = 0.7 + random.nextDouble() * 0.6;
            final value = 120.0 * randomFactor;
            
            data.add({
              'time': 'Semana $week',
              'value': value.toStringAsFixed(1),
            });
          }
        } else if (period == 'year') {
          // Dados para um ano (meses)
          final months = [
            'Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun',
            'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'
          ];
          for (int i = 0; i < 12; i++) {
            // Variação sazonal (mais sol no verão)
            final seasonalFactor = 0.7 + 0.6 * math.sin((i - 3) * math.pi / 6);
            final randomFactor = 0.9 + random.nextDouble() * 0.2;
            final value = 500.0 * seasonalFactor * randomFactor;
            
            data.add({
              'time': months[i],
              'value': value.toStringAsFixed(1),
            });
          }
        }
        
        return {
          'period': period,
          'data': data,
          'timestamp': DateTime.now().toIso8601String(),
        };
      },
    );
  }

  // Obter dados de bateria
  Future<Map<String, dynamic>> getBatteryData() async {
    // Em um aplicativo real, isso faria uma chamada para a API do fabricante
    // Para fins de demonstração, geramos dados simulados
    return Future.delayed(
      const Duration(seconds: 1),
      () {
        final random = math.Random();
        final batteryLevel = 60 + random.nextInt(30);
        final chargePower = random.nextDouble() * 2.5;
        final dischargePower = random.nextDouble() * 1.5;
        
        return {
          'batteryLevel': batteryLevel,
          'chargePower': chargePower.toStringAsFixed(1),
          'dischargePower': dischargePower.toStringAsFixed(1),
          'totalCapacity': '10.0 kWh',
          'availableCapacity': '${(batteryLevel / 10).toStringAsFixed(1)} kWh',
          'estimatedRuntime': '${(batteryLevel / 10).toStringAsFixed(1)} horas',
          'cycleCount': '${200 + random.nextInt(100)}',
          'timestamp': DateTime.now().toIso8601String(),
        };
      },
    );
  }

  // Obter dados meteorológicos
  Future<Map<String, dynamic>> getWeatherData() async {
    // Em um aplicativo real, isso faria uma chamada para uma API meteorológica
    // Para fins de demonstração, geramos dados simulados
    return Future.delayed(
      const Duration(seconds: 1),
      () {
        final random = math.Random();
        final conditions = ['Ensolarado', 'Parcialmente nublado', 'Nublado', 'Chuvoso'];
        final randomCondition = conditions[random.nextInt(conditions.length)];
        final temperature = 20 + random.nextInt(15);
        
        return {
          'condition': randomCondition,
          'temperature': temperature,
          'sunHours': (8 + random.nextInt(5)).toString(),
          'timestamp': DateTime.now().toIso8601String(),
        };
      },
    );
  }

  // Método para conectar a uma API real (exemplo para SolarEdge)
  Future<Map<String, dynamic>> fetchSolarEdgeData(String apiKey, String siteId) async {
    try {
      // Esta é uma chamada de exemplo - em um aplicativo real, você usaria a URL e parâmetros corretos
      final response = await http.get(
        Uri.parse('https://monitoringapi.solaredge.com/site/$siteId/overview?api_key=$apiKey'),
      );
      
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Falha ao carregar dados: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Erro na conexão com a API: $e');
    }
  }

  // Método para conectar a uma API real (exemplo para Fronius)
  Future<Map<String, dynamic>> fetchFroniusData(String ipAddress) async {
    try {
      // Esta é uma chamada de exemplo - em um aplicativo real, você usaria a URL e parâmetros corretos
      final response = await http.get(
        Uri.parse('http://$ipAddress/solar_api/v1/GetInverterRealtimeData.cgi?Scope=Device&DeviceId=1&DataCollection=CommonInverterData'),
      );
      
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Falha ao carregar dados: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Erro na conexão com a API: $e');
    }
  }

  // Método para conectar a uma API personalizada
  Future<Map<String, dynamic>> fetchCustomApiData(String url, {Map<String, String>? headers}) async {
    try {
      final response = await http.get(
        Uri.parse(url),
        headers: headers,
      );
      
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Falha ao carregar dados: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Erro na conexão com a API: $e');
    }
  }
}
