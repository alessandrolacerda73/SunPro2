import 'package:flutter/material.dart';
import '../services/solar_data_service.dart';

class DataConnectionScreen extends StatefulWidget {
  const DataConnectionScreen({super.key});

  @override
  State<DataConnectionScreen> createState() => _DataConnectionScreenState();
}

class _DataConnectionScreenState extends State<DataConnectionScreen> {
  final SolarDataService _dataService = SolarDataService();
  String _selectedManufacturer = 'custom';
  final TextEditingController _apiUrlController = TextEditingController();
  final TextEditingController _apiKeyController = TextEditingController();
  final TextEditingController _systemIdController = TextEditingController();
  bool _isConnecting = false;
  bool _isConnected = false;
  String _connectionStatus = '';

  @override
  void dispose() {
    _apiUrlController.dispose();
    _apiKeyController.dispose();
    _systemIdController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          'Configurar Conexão',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color(0xFF0078D7),
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(
          color: Color(0xFF0078D7),
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildManufacturerSelector(),
              const SizedBox(height: 30),
              _buildConnectionForm(),
              const SizedBox(height: 30),
              _buildConnectionButton(),
              const SizedBox(height: 20),
              if (_connectionStatus.isNotEmpty)
                _buildConnectionStatus(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildManufacturerSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Selecione o Fabricante',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Color(0xFF333333),
          ),
        ),
        const SizedBox(height: 15),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            children: [
              _buildManufacturerOption(
                title: 'SunPower',
                value: 'sunpower',
                icon: Icons.solar_power,
              ),
              const Divider(height: 1),
              _buildManufacturerOption(
                title: 'Fronius',
                value: 'fronius',
                icon: Icons.electrical_services,
              ),
              const Divider(height: 1),
              _buildManufacturerOption(
                title: 'SolarEdge',
                value: 'solaredge',
                icon: Icons.power,
              ),
              const Divider(height: 1),
              _buildManufacturerOption(
                title: 'Enphase',
                value: 'enphase',
                icon: Icons.battery_charging_full,
              ),
              const Divider(height: 1),
              _buildManufacturerOption(
                title: 'Huawei',
                value: 'huawei',
                icon: Icons.devices,
              ),
              const Divider(height: 1),
              _buildManufacturerOption(
                title: 'API Personalizada',
                value: 'custom',
                icon: Icons.code,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildManufacturerOption({
    required String title,
    required String value,
    required IconData icon,
  }) {
    final isSelected = _selectedManufacturer == value;
    
    return InkWell(
      onTap: () {
        setState(() {
          _selectedManufacturer = value;
        });
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: isSelected
                    ? const Color(0xFF0078D7)
                    : const Color(0xFF0078D7).withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                icon,
                color: isSelected ? Colors.white : const Color(0xFF0078D7),
                size: 20,
              ),
            ),
            const SizedBox(width: 15),
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                  color: const Color(0xFF333333),
                ),
              ),
            ),
            if (isSelected)
              const Icon(
                Icons.check_circle,
                color: Color(0xFF0078D7),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildConnectionForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Detalhes da Conexão',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Color(0xFF333333),
          ),
        ),
        const SizedBox(height: 15),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            children: [
              if (_selectedManufacturer == 'custom')
                _buildTextField(
                  controller: _apiUrlController,
                  label: 'URL da API',
                  hint: 'https://exemplo.com/api/solar',
                  icon: Icons.link,
                ),
              _buildTextField(
                controller: _apiKeyController,
                label: 'Chave da API',
                hint: 'Sua chave de API',
                icon: Icons.vpn_key,
              ),
              _buildTextField(
                controller: _systemIdController,
                label: 'ID do Sistema',
                hint: 'ID do seu sistema solar',
                icon: Icons.numbers,
              ),
              const SizedBox(height: 10),
              Text(
                _getConnectionInstructions(),
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey.shade600,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Color(0xFF333333),
            ),
          ),
          const SizedBox(height: 10),
          Container(
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: Colors.grey.shade300,
              ),
            ),
            child: TextField(
              controller: controller,
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: TextStyle(
                  color: Colors.grey.shade400,
                ),
                prefixIcon: Icon(
                  icon,
                  color: const Color(0xFF0078D7),
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 15,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildConnectionButton() {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: _isConnecting ? null : _connectToDataSource,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF0078D7),
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(25),
          ),
          elevation: 5,
        ),
        child: _isConnecting
            ? const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2,
                ),
              )
            : Text(
                _isConnected ? 'Reconectar' : 'Conectar',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
      ),
    );
  }

  Widget _buildConnectionStatus() {
    final isError = _connectionStatus.contains('Erro') || _connectionStatus.contains('Falha');
    
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: isError
            ? Colors.red.shade50
            : Colors.green.shade50,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: isError
              ? Colors.red.shade200
              : Colors.green.shade200,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Icon(
            isError ? Icons.error_outline : Icons.check_circle_outline,
            color: isError ? Colors.red : Colors.green,
            size: 24,
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Text(
              _connectionStatus,
              style: TextStyle(
                fontSize: 14,
                color: isError ? Colors.red.shade800 : Colors.green.shade800,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _getConnectionInstructions() {
    switch (_selectedManufacturer) {
      case 'sunpower':
        return 'Para conectar ao SunPower, você precisará da chave de API e ID do sistema da sua conta mySunpower.';
      case 'fronius':
        return 'Para conectar ao Fronius, use o endereço IP local do seu inversor como ID do Sistema.';
      case 'solaredge':
        return 'Para conectar ao SolarEdge, você precisará da chave de API e ID do site do portal de monitoramento.';
      case 'enphase':
        return 'Para conectar ao Enphase, você precisará da chave de API e ID do sistema do portal Enlighten.';
      case 'huawei':
        return 'Para conectar ao Huawei, você precisará da chave de API e ID da planta do FusionSolar.';
      case 'custom':
      default:
        return 'Para uma API personalizada, forneça a URL completa da API, chave de autenticação (se necessário) e ID do sistema.';
    }
  }

  Future<void> _connectToDataSource() async {
    setState(() {
      _isConnecting = true;
      _connectionStatus = '';
    });

    try {
      final success = await _dataService.configureConnection(
        manufacturer: _getManufacturerType(_selectedManufacturer),
        customApiUrl: _apiUrlController.text,
        apiKey: _apiKeyController.text,
        systemId: _systemIdController.text,
      );

      if (success) {
        // Testar obtendo alguns dados
        final generationData = await _dataService.getCurrentGeneration();
        
        setState(() {
          _isConnected = true;
          _connectionStatus = 'Conexão estabelecida com sucesso! Dados recebidos: ${generationData['currentPower']} de geração atual.';
        });
      } else {
        setState(() {
          _isConnected = false;
          _connectionStatus = 'Falha ao estabelecer conexão. Verifique os dados fornecidos.';
        });
      }
    } catch (e) {
      setState(() {
        _isConnected = false;
        _connectionStatus = 'Erro: $e';
      });
    } finally {
      setState(() {
        _isConnecting = false;
      });
    }
  }
  
  SolarDataService.ManufacturerType _getManufacturerType(String value) {
    switch (value) {
      case 'sunpower':
        return SolarDataService.ManufacturerType.sunpower;
      case 'fronius':
        return SolarDataService.ManufacturerType.fronius;
      case 'solaredge':
        return SolarDataService.ManufacturerType.solaredge;
      case 'enphase':
        return SolarDataService.ManufacturerType.enphase;
      case 'huawei':
        return SolarDataService.ManufacturerType.huawei;
      case 'custom':
      default:
        return SolarDataService.ManufacturerType.custom;
    }
  }
}
