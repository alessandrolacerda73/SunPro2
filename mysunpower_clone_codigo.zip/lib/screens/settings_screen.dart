import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notificationsEnabled = true;
  bool _darkModeEnabled = false;
  bool _autoUpdateEnabled = true;
  double _dataRefreshRate = 5.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(),
            Expanded(
              child: _buildSettingsContent(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            'Ajustes',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Color(0xFF0078D7),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.help_outline),
            onPressed: () {},
            color: const Color(0xFF0078D7),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsContent() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildUserProfile(),
            const SizedBox(height: 30),
            _buildGeneralSettings(),
            const SizedBox(height: 30),
            _buildNotificationSettings(),
            const SizedBox(height: 30),
            _buildDataSettings(),
            const SizedBox(height: 30),
            _buildAboutSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildUserProfile() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              color: const Color(0xFF0078D7).withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: const Center(
              child: Icon(
                Icons.person,
                color: Color(0xFF0078D7),
                size: 40,
              ),
            ),
          ),
          const SizedBox(width: 20),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Usuário Solar',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF333333),
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  'usuario@exemplo.com',
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF666666),
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  'ID: SUN12345',
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF666666),
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            onPressed: () {},
            color: const Color(0xFF0078D7),
          ),
        ],
      ),
    );
  }

  Widget _buildGeneralSettings() {
    return _buildSettingsCard(
      title: 'Configurações Gerais',
      children: [
        _buildSwitchSetting(
          title: 'Modo Escuro',
          subtitle: 'Ativar tema escuro no aplicativo',
          value: _darkModeEnabled,
          onChanged: (value) {
            setState(() {
              _darkModeEnabled = value;
            });
          },
        ),
        const Divider(height: 1),
        _buildSwitchSetting(
          title: 'Atualizações Automáticas',
          subtitle: 'Atualizar o aplicativo automaticamente',
          value: _autoUpdateEnabled,
          onChanged: (value) {
            setState(() {
              _autoUpdateEnabled = value;
            });
          },
        ),
        const Divider(height: 1),
        _buildActionSetting(
          title: 'Idioma',
          subtitle: 'Português (Brasil)',
          icon: Icons.language,
          onTap: () {},
        ),
        const Divider(height: 1),
        _buildActionSetting(
          title: 'Unidades de Medida',
          subtitle: 'kWh, kW',
          icon: Icons.straighten,
          onTap: () {},
        ),
      ],
    );
  }

  Widget _buildNotificationSettings() {
    return _buildSettingsCard(
      title: 'Notificações',
      children: [
        _buildSwitchSetting(
          title: 'Notificações',
          subtitle: 'Ativar todas as notificações',
          value: _notificationsEnabled,
          onChanged: (value) {
            setState(() {
              _notificationsEnabled = value;
            });
          },
        ),
        const Divider(height: 1),
        _buildActionSetting(
          title: 'Alertas de Produção',
          subtitle: 'Diário, Semanal',
          icon: Icons.notifications_active,
          onTap: () {},
          enabled: _notificationsEnabled,
        ),
        const Divider(height: 1),
        _buildActionSetting(
          title: 'Alertas de Bateria',
          subtitle: 'Nível baixo, Carga completa',
          icon: Icons.battery_alert,
          onTap: () {},
          enabled: _notificationsEnabled,
        ),
        const Divider(height: 1),
        _buildActionSetting(
          title: 'Alertas do Sistema',
          subtitle: 'Manutenção, Atualizações',
          icon: Icons.system_update,
          onTap: () {},
          enabled: _notificationsEnabled,
        ),
      ],
    );
  }

  Widget _buildDataSettings() {
    return _buildSettingsCard(
      title: 'Dados e Sincronização',
      children: [
        _buildSliderSetting(
          title: 'Taxa de Atualização',
          subtitle: 'A cada ${_dataRefreshRate.toInt()} minutos',
          value: _dataRefreshRate,
          min: 1,
          max: 30,
          divisions: 29,
          onChanged: (value) {
            setState(() {
              _dataRefreshRate = value;
            });
          },
        ),
        const Divider(height: 1),
        _buildActionSetting(
          title: 'Sincronizar Agora',
          subtitle: 'Última sincronização: Hoje, 14:30',
          icon: Icons.sync,
          onTap: () {},
        ),
        const Divider(height: 1),
        _buildActionSetting(
          title: 'Armazenamento de Dados',
          subtitle: '24.5 MB utilizados',
          icon: Icons.storage,
          onTap: () {},
        ),
        const Divider(height: 1),
        _buildActionSetting(
          title: 'Exportar Dados',
          subtitle: 'CSV, PDF',
          icon: Icons.download,
          onTap: () {},
        ),
      ],
    );
  }

  Widget _buildAboutSection() {
    return _buildSettingsCard(
      title: 'Sobre',
      children: [
        _buildActionSetting(
          title: 'Versão do Aplicativo',
          subtitle: '1.0.0 (Build 2025041901)',
          icon: Icons.info_outline,
          onTap: () {},
        ),
        const Divider(height: 1),
        _buildActionSetting(
          title: 'Termos de Serviço',
          subtitle: 'Políticas e condições',
          icon: Icons.description_outlined,
          onTap: () {},
        ),
        const Divider(height: 1),
        _buildActionSetting(
          title: 'Política de Privacidade',
          subtitle: 'Como seus dados são utilizados',
          icon: Icons.privacy_tip_outlined,
          onTap: () {},
        ),
        const Divider(height: 1),
        _buildActionSetting(
          title: 'Suporte',
          subtitle: 'Ajuda e contato',
          icon: Icons.support_agent,
          onTap: () {},
        ),
        const Divider(height: 1),
        _buildActionSetting(
          title: 'Sair',
          subtitle: 'Encerrar sessão atual',
          icon: Icons.logout,
          onTap: () {},
          textColor: Colors.red,
        ),
      ],
    );
  }

  Widget _buildSettingsCard({
    required String title,
    required List<Widget> children,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Color(0xFF333333),
          ),
        ),
        const SizedBox(height: 15),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            children: children,
          ),
        ),
      ],
    );
  }

  Widget _buildSwitchSetting({
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: Color(0xFF333333),
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: const Color(0xFF0078D7),
          ),
        ],
      ),
    );
  }

  Widget _buildActionSetting({
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback onTap,
    bool enabled = true,
    Color? textColor,
  }) {
    return InkWell(
      onTap: enabled ? onTap : null,
      child: Opacity(
        opacity: enabled ? 1.0 : 0.5,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: const Color(0xFF0078D7).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  icon,
                  color: const Color(0xFF0078D7),
                  size: 20,
                ),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        color: textColor ?? const Color(0xFF333333),
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.chevron_right,
                color: Colors.grey.shade400,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSliderSetting({
    required String title,
    required String subtitle,
    required double value,
    required double min,
    required double max,
    required int divisions,
    required ValueChanged<double> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Color(0xFF333333),
            ),
          ),
          const SizedBox(height: 5),
          Text(
            subtitle,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey.shade600,
            ),
          ),
          const SizedBox(height: 10),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: const Color(0xFF0078D7),
              inactiveTrackColor: const Color(0xFF0078D7).withOpacity(0.2),
              thumbColor: const Color(0xFF0078D7),
              overlayColor: const Color(0xFF0078D7).withOpacity(0.2),
              valueIndicatorColor: const Color(0xFF0078D7),
              valueIndicatorTextStyle: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
            child: Slider(
              value: value,
              min: min,
              max: max,
              divisions: divisions,
              label: value.toInt().toString(),
              onChanged: onChanged,
            ),
          ),
        ],
      ),
    );
  }
}
