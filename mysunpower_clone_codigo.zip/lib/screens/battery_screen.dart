import 'package:flutter/material.dart';
import 'dart:math' as math;

class BatteryScreen extends StatefulWidget {
  const BatteryScreen({super.key});

  @override
  State<BatteryScreen> createState() => _BatteryScreenState();
}

class _BatteryScreenState extends State<BatteryScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _batteryAnimation;
  late Animation<double> _flowAnimation;
  
  final List<String> _modes = ['Auto', 'Economia', 'Reserva'];
  String _selectedMode = 'Auto';
  double _batteryLevel = 85;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
    
    _batteryAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );
    
    _flowAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(),
            Expanded(
              child: _buildBatteryContent(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            'Bateria',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Color(0xFF0078D7),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.info_outline),
            onPressed: () {},
            color: const Color(0xFF0078D7),
          ),
        ],
      ),
    );
  }

  Widget _buildBatteryContent() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildBatteryStatus(),
            const SizedBox(height: 30),
            _buildEnergyFlow(),
            const SizedBox(height: 30),
            _buildModeSelector(),
            const SizedBox(height: 30),
            _buildBatteryDetails(),
          ],
        ),
      ),
    );
  }

  Widget _buildBatteryStatus() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          const Text(
            'Status da Bateria',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFF333333),
            ),
          ),
          const SizedBox(height: 30),
          AnimatedBuilder(
            animation: _batteryAnimation,
            builder: (context, child) {
              return Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    height: 200,
                    width: 100,
                    child: CustomPaint(
                      painter: BatteryPainter(
                        batteryLevel: _batteryLevel / 100,
                        animationValue: _batteryAnimation.value,
                      ),
                    ),
                  ),
                  Text(
                    '${_batteryLevel.toInt()}%',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              );
            },
          ),
          const SizedBox(height: 30),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.access_time,
                color: Color(0xFF666666),
                size: 18,
              ),
              const SizedBox(width: 5),
              Text(
                'Tempo estimado restante: ${(_batteryLevel / 10).toStringAsFixed(1)} horas',
                style: const TextStyle(
                  fontSize: 14,
                  color: Color(0xFF666666),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEnergyFlow() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          const Text(
            'Fluxo de Energia',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFF333333),
            ),
          ),
          const SizedBox(height: 30),
          AnimatedBuilder(
            animation: _flowAnimation,
            builder: (context, child) {
              return SizedBox(
                height: 120,
                child: Stack(
                  children: [
                    // Sol
                    Positioned(
                      left: 20,
                      top: 10,
                      child: Column(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFB74D),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFFFFB74D).withOpacity(0.3),
                                  blurRadius: 10,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.wb_sunny,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                          const SizedBox(height: 10),
                          const Text(
                            'Solar',
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF666666),
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    // Casa
                    Positioned(
                      left: 0,
                      right: 0,
                      top: 10,
                      child: Column(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: const Color(0xFF0078D7),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFF0078D7).withOpacity(0.3),
                                  blurRadius: 10,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.home,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                          const SizedBox(height: 10),
                          const Text(
                            'Casa',
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF666666),
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    // Bateria
                    Positioned(
                      right: 20,
                      top: 10,
                      child: Column(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: const Color(0xFF4CAF50),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFF4CAF50).withOpacity(0.3),
                                  blurRadius: 10,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.battery_charging_full,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                          const SizedBox(height: 10),
                          const Text(
                            'Bateria',
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF666666),
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    // Linhas de fluxo animadas
                    CustomPaint(
                      size: const Size(double.infinity, 120),
                      painter: EnergyFlowPainter(
                        animationValue: _flowAnimation.value,
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildFlowMetric(
                title: 'Solar → Casa',
                value: '3.2 kW',
                color: const Color(0xFFFFB74D),
              ),
              _buildFlowMetric(
                title: 'Solar → Bateria',
                value: '1.8 kW',
                color: const Color(0xFF4CAF50),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFlowMetric({
    required String title,
    required String value,
    required Color color,
  }) {
    return Column(
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey.shade600,
          ),
        ),
        const SizedBox(height: 5),
        Row(
          children: [
            Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(
                color: color,
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 5),
            Text(
              value,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color(0xFF333333),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildModeSelector() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Modo de Operação',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFF333333),
            ),
          ),
          const SizedBox(height: 20),
          Container(
            height: 50,
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(25),
            ),
            child: Row(
              children: _modes.map((mode) {
                final isSelected = mode == _selectedMode;
                return Expanded(
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        _selectedMode = mode;
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: isSelected ? const Color(0xFF0078D7) : Colors.transparent,
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: Center(
                        child: Text(
                          mode,
                          style: TextStyle(
                            color: isSelected ? Colors.white : Colors.grey.shade700,
                            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 20),
          _buildModeDescription(),
        ],
      ),
    );
  }

  Widget _buildModeDescription() {
    String description = '';
    IconData icon = Icons.auto_awesome;
    Color color = const Color(0xFF0078D7);
    
    switch (_selectedMode) {
      case 'Auto':
        description = 'Otimiza automaticamente o uso da bateria com base no seu padrão de consumo e previsão de geração solar.';
        icon = Icons.auto_awesome;
        color = const Color(0xFF0078D7);
        break;
      case 'Economia':
        description = 'Prioriza o uso da bateria durante horários de pico para reduzir custos de energia da rede.';
        icon = Icons.savings;
        color = const Color(0xFFFFB74D);
        break;
      case 'Reserva':
        description = 'Mantém a bateria carregada para uso em caso de queda de energia, priorizando a segurança.';
        icon = Icons.shield;
        color = const Color(0xFF4CAF50);
        break;
    }
    
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: color,
            size: 24,
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Text(
              description,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBatteryDetails() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Detalhes da Bateria',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFF333333),
            ),
          ),
          const SizedBox(height: 20),
          _buildDetailItem(
            title: 'Capacidade Total',
            value: '10 kWh',
            icon: Icons.battery_full,
            color: const Color(0xFF4CAF50),
          ),
          const Divider(height: 30),
          _buildDetailItem(
            title: 'Energia Armazenada',
            value: '8.5 kWh',
            icon: Icons.battery_charging_full,
            color: const Color(0xFF0078D7),
          ),
          const Divider(height: 30),
          _buildDetailItem(
            title: 'Potência Atual',
            value: '1.8 kW',
            icon: Icons.bolt,
            color: const Color(0xFFFFB74D),
          ),
          const Divider(height: 30),
          _buildDetailItem(
            title: 'Ciclos de Carga',
            value: '245',
            icon: Icons.loop,
            color: const Color(0xFF9E9E9E),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailItem({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(
            icon,
            color: color,
            size: 24,
          ),
        ),
        const SizedBox(width: 15),
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Color(0xFF333333),
            ),
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Color(0xFF333333),
          ),
        ),
      ],
    );
  }
}

class BatteryPainter extends CustomPainter {
  final double batteryLevel;
  final double animationValue;
  
  BatteryPainter({
    required this.batteryLevel,
    required this.animationValue,
  });
  
  @override
  void paint(Canvas canvas, Size size) {
    // Desenhar contorno da bateria
    final batteryOutline = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, size.width, size.height),
      const Radius.circular(15),
    );
    
    final outlinePaint = Paint()
      ..color = Colors.grey.shade300
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    
    canvas.drawRRect(batteryOutline, outlinePaint);
    
    // Desenhar terminal da bateria
    final terminalPaint = Paint()
      ..color = Colors.grey.shade300
      ..style = PaintingStyle.fill;
    
    final terminalRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(
        size.width * 0.3,
        -10,
        size.width * 0.4,
        10,
      ),
      const Radius.circular(5),
    );
    
    canvas.drawRRect(terminalRect, terminalPaint);
    
    // Determinar cor da bateria com base no nível
    Color batteryColor;
    if (batteryLevel > 0.6) {
      batteryColor = const Color(0xFF4CAF50); // Verde
    } else if (batteryLevel > 0.3) {
      batteryColor = const Color(0xFFFFB74D); // Laranja
    } else {
      batteryColor = const Color(0xFFF44336); // Vermelho
    }
    
    // Desenhar nível da bateria com efeito de pulso
    final levelPaint = Paint()
      ..color = batteryColor
      ..style = PaintingStyle.fill;
    
    // Adicionar efeito de pulso sutil
    final pulseOffset = math.sin(animationValue * math.pi) * 3;
    
    final levelHeight = size.height * batteryLevel;
    final levelRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(
        5,
        size.height - levelHeight,
        size.width - 10,
        levelHeight - 5 + pulseOffset,
      ),
      const Radius.circular(10),
    );
    
    canvas.drawRRect(levelRect, levelPaint);
    
    // Adicionar brilho na parte superior
    final highlightPaint = Paint()
      ..color = Colors.white.withOpacity(0.3)
      ..style = PaintingStyle.fill;
    
    final highlightRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(
        10,
        size.height - levelHeight + 5,
        size.width - 20,
        10,
      ),
      const Radius.circular(5),
    );
    
    canvas.drawRRect(highlightRect, highlightPaint);
  }
  
  @override
  bool shouldRepaint(covariant BatteryPainter oldDelegate) {
    return oldDelegate.batteryLevel != batteryLevel ||
           oldDelegate.animationValue != animationValue;
  }
}

class EnergyFlowPainter extends CustomPainter {
  final double animationValue;
  
  EnergyFlowPainter({
    required this.animationValue,
  });
  
  @override
  void paint(Canvas canvas, Size size) {
    final centerY = size.height * 0.3;
    
    // Linha do Sol para a Casa
    final solarToHomePath = Path()
      ..moveTo(60, centerY)
      ..lineTo(size.width / 2 - 20, centerY);
    
    final solarToHomePaint = Paint()
      ..color = const Color(0xFFFFB74D)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    
    canvas.drawPath(solarToHomePath, solarToHomePaint);
    
    // Linha do Sol para a Bateria
    final solarToBatteryPath = Path()
      ..moveTo(60, centerY)
      ..quadraticBezierTo(
        size.width / 2,
        centerY + 40,
        size.width - 60,
        centerY,
      );
    
    final solarToBatteryPaint = Paint()
      ..color = const Color(0xFF4CAF50)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    
    canvas.drawPath(solarToBatteryPath, solarToBatteryPaint);
    
    // Partículas animadas na linha Sol-Casa
    final particleOffset = (animationValue * 40) % 40;
    for (int i = 0; i < 5; i++) {
      final particlePosition = 60 + i * 40 + particleOffset;
      if (particlePosition < size.width / 2 - 20) {
        canvas.drawCircle(
          Offset(particlePosition, centerY),
          3,
          Paint()..color = const Color(0xFFFFB74D),
        );
      }
    }
    
    // Partículas animadas na curva Sol-Bateria
    for (int i = 0; i < 8; i++) {
      final t = (i * 0.125 + animationValue * 0.5) % 1.0;
      final x = _bezierX(60, size.width / 2, size.width - 60, t);
      final y = _bezierY(centerY, centerY + 40, centerY, t);
      
      canvas.drawCircle(
        Offset(x, y),
        3,
        Paint()..color = const Color(0xFF4CAF50),
      );
    }
  }
  
  double _bezierX(double x1, double x2, double x3, double t) {
    return (1 - t) * (1 - t) * x1 + 2 * (1 - t) * t * x2 + t * t * x3;
  }
  
  double _bezierY(double y1, double y2, double y3, double t) {
    return (1 - t) * (1 - t) * y1 + 2 * (1 - t) * t * y2 + t * t * y3;
  }
  
  @override
  bool shouldRepaint(covariant EnergyFlowPainter oldDelegate) {
    return oldDelegate.animationValue != animationValue;
  }
}
